
  # Wireframe de Ferramenta de Acessibilidade

  This is a code bundle for Wireframe de Ferramenta de Acessibilidade. The original project is available at https://www.figma.com/design/vrj7nU4Scaej7RfUCGz6XL/Wireframe-de-Ferramenta-de-Acessibilidade.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  